﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ChipMongWebApp.Models.DTO.SSA
{
    public class GetSSADTO<T>
    {
        public List<T> results;
    }
}