﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ChipMongWebApp.Models.DTO.DealerSourceSupply
{
    public class DealerSourceSupplyDTO
    {
        public int id { get; set; }
        public string name { get; set; }
        public int sourceSupplyID { get; set; }
    }
}